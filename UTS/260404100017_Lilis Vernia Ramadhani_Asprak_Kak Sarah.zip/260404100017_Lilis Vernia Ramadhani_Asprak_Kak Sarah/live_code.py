regular = 40000
vip = 75000
vvip = 100000

tiket = 0
total = 0
total_akhir = 0
total_bayar = 0
while True:
    tiket = input("masukan jenis tiket regular/vip/vvip dan 0 untuk selesai") # memasukkan input tiket yang dibeli dan 0 untuk menghentikan proses input tiket
    
    if tiket == 0: #input tiket selesai
        break 
    
    if tiket = regular:
        print("tambahan minuman seharga Rp.10.000per tiket Y/y") #untuk menawarkan tambahan dan memasukkan perintah Y/y
        total_akhir = regular + 10000 #untuk menampilkan harga tiket
    else:
        print("mendapatkan minuman gratis")
        total_akhir = vip or  vvip # untuk menampilkan harga tiket
        continue #untuk mengulang penginputan

    total = tiket +1  # untuk menambahkan jumlah tiket

total_akhir= total_akhir #


    if total >=3: # jika total keseluruhan tiket lebih dari 3 akan mendapat diskon
        if memiliki_membercard:
            total_akhir = total_akhir * 1.5 # akan mendapat diskon 15% jika memiliki member card
        else:
            total_akhir = total_akhir * 0.1 # akan mendapat diskon 10% jika tidak memiliki member card
    else:
        total_akhir = total_akhir #jika tiket kurang dari 3, tidak mendapat diskon

    while True:
        total_bayar = input("masukkan total bayar=") #untuk memasukkan total bayar
        if total_bayar < total_akhir: #jika total bayar tidak sama dengan total akhir maka akan meminta input lagi
            print("total bayar tidak valid")
            continue
        else:
           break  #jika total bayar sesuai, maka program akan selesai

        kembalian = total_bayar- total_akhir # untuk menghitung kembalian
        print("kembalian anda= ", kembalian)
